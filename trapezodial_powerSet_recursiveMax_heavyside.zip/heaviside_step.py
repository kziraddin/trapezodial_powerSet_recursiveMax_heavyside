def heaviside_step(x):
    if x < 0:
        return 0
    elif x >= 0:
        return 1
    else:
        # Handle other cases if needed (e.g., x is not a number)
        return None

# Example usage:
x = 5
result = heaviside_step(x)
print(f"Heaviside step function H({x}) = {result}")


"""In this code:

The heaviside_step function takes a real number x as input and uses conditional statements 
to return 0 if x is less than 0 or 1 if x is greater than or equal to 0.

The else block can be used to handle other cases if needed, such as when x is not a number.

You can call the heaviside_step function with different values of x to calculate the Heaviside step function for those values."""