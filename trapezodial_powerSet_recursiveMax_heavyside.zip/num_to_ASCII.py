
# Create a list of numbers from 97 to 122 using list comprehension
numbers = [i for i in range(97, 123)]

# Define a function to convert a number to its corresponding ASCII character
def number_to_char(num):
    return chr(num)

# Use map() to apply the function to each number in the list
ascii_chars = list(map(number_to_char, numbers))     # map(function, iterable)

# Iterate over the map object using a for loop and print each character
for char in ascii_chars:
    print(char)


"""In this script:

We use list comprehension to create a list called numbers containing integers from 97 to 122.

We define a function number_to_char(num) that converts a number to its corresponding ASCII character using the chr() function.

We use the map() function to apply the number_to_char function to each number in the numbers list, resulting in a map object.

We convert the map object to a list using list(map_object) to make it iterable.

Finally, we use a for loop to iterate over the list of ASCII characters and print them one by one."""