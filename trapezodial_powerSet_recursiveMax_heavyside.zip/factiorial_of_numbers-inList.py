import math

# Create a list of 10 numbers from 10 to 19
numbers = list(range(10, 20))

# Use map() to generate factorials of the numbers
factorials = list(map(math.factorial, numbers))

# Print the list of factorials
print("Factorials of the numbers:", factorials)
