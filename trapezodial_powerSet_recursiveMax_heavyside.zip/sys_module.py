import sys

# Access the sys.copyright attribute to get copyright information
copyright_info = sys.copyright

# Print the copyright information
print(copyright_info)


"""When you run this code, it will print out the copyright information for Python, 
including the license under which Python is distributed. The sys.copyright attribute contains this information as a string."""