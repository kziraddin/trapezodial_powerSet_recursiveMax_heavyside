user_input = input("Enter a list of numbers separated by spaces (e.g., 1 2 3): ")

#covert str to int
user_input_str = user_input.split()

# create list of integers
list_of_numbers = [int(num) for num in user_input_str]


def find_max_recursive(list_of_numbers):

    if not list_of_numbers:
        return None
    if len(list_of_numbers) == 1:
        return list_of_numbers[0]

    first_element = list_of_numbers[0]
    rest_of_list = list_of_numbers[1:]

    max_rest = find_max_recursive(rest_of_list)

    return max(first_element, max_rest)

# Call the find_max_recursive function and print the result
max_value = find_max_recursive(list_of_numbers)
if max_value is not None:
    print("The maximum value in the list is:", max_value)
else:
    print("The list is empty.")

    
        
"""In this recursive solution:

The find_max_recursive function takes a list of integers as its argument.

In the base case, if the list is empty, it returns None. If there's only one element in the list, it returns that element.

In the recursive case, the function compares the first element of the list (first_element) 
with the maximum of the rest of the list (max_rest) obtained by making a recursive call.

The max() function is used to find the maximum between first_element and max_rest, which is then returned.

The function recursively breaks down the list into smaller parts and finds the maximum among them until the base cases are reached. 
The example usage demonstrates finding the maximum number in a list of integers."""