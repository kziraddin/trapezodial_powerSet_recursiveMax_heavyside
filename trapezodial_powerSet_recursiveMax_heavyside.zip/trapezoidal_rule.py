import numpy as np
import math

def trapezoidal_rule(f, a, b, n):
    """
    Calculates the definite integral of a function f(x), between the boundaries "a" and "b",
    by dividing the area into "n" equal trapezoids/strips.

    Parameters:
        f (function): The function to be integrated.
        a (float): The lower limit of integration.
        b (float): The upper limit of integration.
        n (int): The number of intervals (subintervals) to use in the Trapezoidal rule.

    Returns:
        float: The approximate value of the definite integral.
    """
    h = (b - a) / n  # Width of each subinterval

    integral_approximation = 0.5 * (f(a) + f(b))
    for i in range(1, n):
        x_i = a + i * h
        integral_approximation += f(x_i)

    integral_approximation *= h

    return integral_approximation

# # Example usage:
# def example_function(x):
#     return  1 / x

# a = 1  # Lower limit of integration
# b = 2  # Upper limit of integration
# n = 100  # Number of subintervals (increase for higher accuracy)

# result = trapezoidal_rule(example_function, a, b, n)
# print(f"Approximate integral: {result}")


# Example usage for ∫_0^π sin(x)dx:
def sin_function(x):
    return math.sin(x)


a = 0    # Lower limit of integration
b = math.pi   # Upper limit of integration (π)
n = 1000   # Number of subintervals (increase for higher accuracy)

result = trapezoidal_rule(sin_function, a , b, n)
print(f"Approximate integral: {result}")