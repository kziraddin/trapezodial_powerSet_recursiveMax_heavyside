user_input = input("Enter a list of numbers separated by spaces (e.g., 1 2 3): ")

# Split the user input into a list of strings using space as the delimiter
input_numbers_str = user_input.split()

# Convert the list of strings to a list of integers
input_numbers = [int(num) for num in input_numbers_str]


# Use filter() with a lambda function to filter out even numbers
filtered_numbers = list(filter(lambda x: x % 2 == 0, input_numbers))

square_of_filtered_numbers = list(map(lambda x: x ** 2, filtered_numbers))

result = filtered_numbers.sort()

# Print the filtered list
print("EVEN numbers:", filtered_numbers)


"""In this script:

We use the input() function to get a string of numbers from the user.

We split the user input into a list of strings using the split() method, 
which splits the input string at spaces (the default delimiter) and stores the parts as separate strings.

We use a list comprehension to convert each string in the list to an integer using int(), resulting in a list of integers.

Finally, we print the list of numbers entered by the user.

Keep in mind that this method assumes that the user will provide numbers separated by spaces. """