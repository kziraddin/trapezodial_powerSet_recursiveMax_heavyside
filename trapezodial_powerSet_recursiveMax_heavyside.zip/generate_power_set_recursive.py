
"""In mathematics, the power set of a set is a set that contains all possible subsets of the original set, 
including the original set itself and the empty set. The power set is denoted by the symbol ℘ or P."""


def generate_power_set(input_list):
    if len(input_list) == 0:
        return [[]]

    first_element = input_list[0]
    rest_of_list = input_list[1:]

    # Recursive call to generate the power set for the rest of the list
    subsets_without_first = generate_power_set(rest_of_list)

    subsets_with_first = [[first_element]+ subset for subset in subsets_without_first]

    power_set = subsets_without_first + subsets_with_first

    return power_set


#example
original_list = [1,2,3]

result_of_power_set = generate_power_set(original_list)

print(result_of_power_set)


"""In this recursive approach:

The generate_power_set_recursive function takes an input list as an argument.

If the input list is empty, it returns a list containing the empty list, which represents the power set of an empty set.

If the input list is not empty, it divides the list into the first element and the rest of the list.

It recursively calculates the power set for the rest of the list.

For each subset in the power set of the rest of the list, it creates a corresponding subset that includes the first element. 
These subsets are combined to form the power set of the original list.

"""