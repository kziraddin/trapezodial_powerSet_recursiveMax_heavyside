import math

user_input = input("Enter the numbers seperated by spaces: ")

user_input_str = user_input.split()

list_of_numbers = [int(num) for num in user_input_str]

list_of_squared_numbers = list(map(lambda x: x ** 2, list_of_numbers))

print(list_of_squared_numbers)


